1. quatro desvantagens do DTD sobre o XML Schema
2. apresente um scrip PHP DOM que cire ficjeciro XML com conteudo apresentado na figura
